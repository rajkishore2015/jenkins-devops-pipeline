package com.uhg.ehcache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EhcacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
